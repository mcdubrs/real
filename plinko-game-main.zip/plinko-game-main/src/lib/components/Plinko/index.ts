export { default } from './Plinko.svelte';
